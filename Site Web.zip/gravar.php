<?PHP

include "conexao.php";

$nome = $_POST['nome'];
$historia = $_POST['historia'];
$data = new DateTime('now');
$data = $data->format('Y-m-d H:i:s');

$stmt = $db->prepare("INSERT INTO historias (nome, historia, data) VALUES (:nome, :historia, :data)");
$stmt->bindValue(':nome', $nome, PDO::PARAM_STR);
$stmt->bindValue(':historia', $historia, PDO::PARAM_STR);
$stmt->bindValue(':data', $data);
$stmt->execute();
$result = $stmt->rowCount();
if($result > 0){
    header("location: index.php#msg");
} else {
    var_dump("IH RAPAZ DEU ERRO AQUI, DEVE SER ALGO NO SEU CODIGO DE CONEXAO EM!");
}


