<?PHP
include "conexao.php";

$query = $db->prepare("Select * FROM historias");
$query->execute();
$msgs = $query->fetchall(PDO::FETCH_ASSOC);

?>
<html lang="pt-br">
    <head>
        <meta charset="utf-8">
        <title>Cervejas</title> 
        <link href="style.css" rel="stylesheet" />
    </head>

    <body>
        <header id="topo">
            <nav>
                <img id="logo" src="logo.png"/>
                <ul>
                    <li><a href="#topo">Topo</a></li>
                    <li><a href="#sobre">Mais sobre a cerveja</a></li>
                    <li><a href="#msg">Conte sua historia</a></li>
                </ul>

            </nav>
        </header>
        <div id="cabecalho">
            <h1>Apenas um tributo a cerveja!</h1>
        </div>
        <article>
            <p>
                A cerveja (do gaulês, através do latim servisia) é uma bebida produzida a partir da fermentação de cereais, principalmente a cevada maltada. Acredita-se que tenha sido uma das primeiras bebidas alcoólicas que foram criadas pelo ser humano. Atualmente, é a terceira bebida mais popular do mundo, logo depois da água e do café. É a bebida alcoólica mais consumida no mundo atualmente.
            </p>
        </article>
        <div id="sobre">
            <div>
                <figure><img src="beer1.jpg" class="galeria"></figure>
                <figure><img src="beer2.jpg" class="galeria"></figure>
                <figure><img src="beer3.jpg" class="galeria"></figure>
                <figure><img src="beer4.jpg" class="galeria"></figure>
            </div>
            <div id="cabecalho">
                <h1>Mais sobre historia da cerveja</h1>
            </div>
            <article>
                <p>
                    Historicamente, a cerveja já era conhecida pelos antigos sumérios, egípcios, mesopotâmios e iberos, remontando, pelo menos, a 6 000 a.C. A agricultura surgiu na Mesopotâmia em um período entre a revolução do Neolítico e a Idade dos Metais. A mais antiga lei que regulamenta a produção e a venda de cerveja é a Estela de Hamurabi, que data de 1 760 a.C. Nela, se condena à morte quem não respeita os critérios de produção de cerveja indicados. Incluía várias leis de comercialização, fabricação e consumo da cerveja, relacionando direitos e deveres dos clientes das tabernas. O Código de Hamurabi também estabelecia uma ração diária de cerveja para o povo da Babilônia: 2 litros para os trabalhadores, 3 para os funcionários públicos e 5 para os administradores e o sumo sacerdote. O código também impunha punições severas para os taberneiros que tentassem enganar os seus clientes.

                    A notícia mais antiga que se tem da cerveja vem de 2 600 a 2 350 a.C. Desta época, arqueólogos encontraram menção no Hino a Ninkasi, a deusa da cerveja, de que os sumérios já produziam a bebida. Já na Babilônia dá-se conta da existência de diferentes tipos de cerveja, originadas de diversas combinações de plantas e aromas, e o uso de diferentes quantidades de mel.

                    Posteriormente, no antigo Egito, a cerveja, segundo o escritor grego Ateneu de Náucrates (século III), teria sido inventada para ajudar a quem não tinha como pagar o vinho. Inscrições em hieróglifos e obras artísticas testemunham o gosto deste povo pelo henket ou zythum, apreciado por todas as camadas sociais. Até um dos faraós, Ramsés III (1 184-1 153 a.C.), passou a ser conhecido como "faraó-cervejeiro" após doar, aos sacerdotes do Templo de Amon, 466 308 ânforas ou aproximadamente um milhão de litros de cerveja provenientes de suas cervejeiras.

                    Praticamente qualquer açúcar ou alimento que contenha amido pode, naturalmente, sofrer fermentação alcoólica. Assim, bebidas semelhantes à cerveja foram inventadas de forma independente em diversas sociedades em redor do mundo. Na Mesopotâmia, a mais antiga evidência referente à cerveja está numa tabua sumeriana com cerca de 6000 anos de idade na qual se veem pessoas tomando uma bebida através de juncos de uma tigela comunitária. A cerveja também é mencionada na Epopeia de Gilgamesh. Um poema sumeriano de 3900 anos homenageando a deusa dos cervejeiros, Ninkasi, contém a mais antiga receita que sobreviveu, descrevendo a produção de cerveja de cevada utilizando pão.

                    A cerveja teve alguma importância na vida dos primeiros romanos, mas, durante a República Romana, o vinho destronou a cerveja como a bebida alcoólica preferida, passando esta a ser considerada uma bebida própria de bárbaros. Tácito, em seus dias, escreveu depreciativamente acerca da cerveja preparada pelos povos germânicos.
                </p>
            </article>
        </div>

        <div id="msg">
            <div id="msgInsert">
                <div id="cabecalho">
                    <h1>Nos conte a sua historia com a cerveja </h1>
                </div>
                <form action="gravar.php" enctype="multipart/form-data" method="post">
                    <input type="text" placeholder="Seu Nome" name="nome" maxlength="100" />
                    <textarea placeholder="Conte sua historia com a ceveja" name="historia" ></textarea>
                    <button type="submit" role="button">Enviar</button>
                </form>
            </div>
            <br/> <br />
            <div >
                <div id="cabecalho">
                    <h1>Historias ja contadas</h1>
                </div>
                <table>
                    <thead>
                        <tr>
                            <th>Nome</th>
                            <th>Mensagem</th>
                            <th>Data</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?PHP foreach($msgs as $msg){ ?>
                        <tr>
                            <td><?=$msg['nome']?></td>
                            <td><?=$msg['historia']?></td>
                            <td><?=$msg['data']?></td>
                        </tr>
                        <?PHP } ?>
                    </tbody>
                </table>
            </div>
        </div>
    </body>
</html>