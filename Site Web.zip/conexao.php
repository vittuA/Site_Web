<?PHP

$urlConnexao = 'mysql:host=localhost;dbname=id3906034_cervejas;charset=utf8';
$usuario = 'id3906034_vitor';
$senha = 'admin123';
$db = new PDO( $urlConnexao, $usuario, $senha );

?>